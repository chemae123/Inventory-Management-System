document.addEventListener('DOMContentLoaded', () => {
    // Retrieve data from local storage
    const products = JSON.parse(localStorage.getItem('products')) || [];

    // Select the product table body
    const productTableBody = document.getElementById('productTableBody');
    productTableBody.innerHTML = '';

    // Populate the product table
    products.forEach((product, index) => {
        const row = `
            <tr>
                <td>
                    <label class="checkboxs">
                        <input type="checkbox" id="select-${index}">
                        <span class="checkmarks"></span>
                    </label>
                </td>
                <td></td>
                <td>${product.productName}</td>
                <td>${product.sku}</td>
                <td>${product.category}</td>
                <td>${product.subCategory}</td>
                <td>${product.brand}</td>
                <td>${product.price}</td>
                <td>${product.unit}</td>
                <td>${product.qty}</td>
                <td>Admin</td>
                <td>
                    <a class="me-3" href="product-details.html">
                        <img src="assets/img/icons/eye.svg" alt="View">
                    </a>
                    <a class="me-3" href="javascript:void(0);" onclick="editProduct(0)">
                        <img src="assets/img/icons/edit.svg" alt="Edit">
                    </a>
                    <a class="confirm-text" href="javascript:void(0);" onclick="deleteProduct(0)">
                        <img src="assets/img/icons/delete.svg" alt="Delete">
                    </a>
                </td>
            </tr>
        `;
        productTableBody.innerHTML += row;
    });
});

function saveProductData() {
    // Get input values
    const productName = document.getElementById('productName').value;
    const category = document.getElementById('category').value;
    const subCategory = document.getElementById('subCategory').value;
    const brand = document.getElementById('brand').value;
    const unit = document.getElementById('unit').value;
    const sku = document.getElementById('sku').value;
    const minQty = document.getElementById('minQty').value;
    const qty = document.getElementById('qty').value;
    const description = document.getElementById('description').value;
    const tax = document.getElementById('tax').value;
    const discountType = document.getElementById('discountType').value;
    const price = document.getElementById('price').value;
    const status = document.getElementById('status').value;

    // Create product object
    const productData = {
        productName,
        category,
        subCategory,
        brand,
        unit,
        sku,
        minQty,
        qty,
        description,
        tax,
        discountType,
        price,
        status
    };

    // Check if 'products' already exists in local storage
    if (localStorage.getItem('products')) {
        // Retrieve existing products data from local storage
        const existingProducts = JSON.parse(localStorage.getItem('products'));

        // Add new product data to existing data
        existingProducts.push(productData);

        // Update 'products' in local storage
        localStorage.setItem('products', JSON.stringify(existingProducts));
    } else {
        // Create new 'products' array and add the product data
        const newProducts = [productData];

        // Set 'products' in local storage
        localStorage.setItem('products', JSON.stringify(newProducts));
    }

    // Redirect to productlist.html
    window.location.href = 'productlist.html';

    // Alert the user that the data has been saved
    alert('Product data has been saved successfully!');
}

function editProduct(index) {
    const products = JSON.parse(localStorage.getItem('products')) || [];
    const productData = products[index];
    sessionStorage.setItem('editedProduct', JSON.stringify(productData));
    window.location.href = `editproduct.html?index=${index}`;
}

function deleteProduct(index) {
    const products = JSON.parse(localStorage.getItem('products')) || [];
    products.splice(index, 1);
    localStorage.setItem('products', JSON.stringify(products));
    window.location.reload();
}


document.addEventListener('DOMContentLoaded', () => {
    // Retrieve data from local storage
    const categories = JSON.parse(localStorage.getItem('category')) || [];
    const subCategories = JSON.parse(localStorage.getItem('subCategories')) || [];
    const brands = JSON.parse(localStorage.getItem('brand')) || [];
    const products = JSON.parse(localStorage.getItem('products')) || [];

    // Select the category, subcategory, and brand dropdowns
    const categorySelect = document.getElementById('category');
    const subCategorySelect = document.getElementById('subCategory');
    const brandSelect = document.getElementById('brand');

    // Clear existing options
    categorySelect.innerHTML = '<option>Choose Category</option>';
    subCategorySelect.innerHTML = '<option>Choose Sub Category</option>';
    brandSelect.innerHTML = '<option>Choose Brand</option>';

    // Populate the select element with category names
    categories.forEach(category => {
        const option = document.createElement('option');
        option.value = category.catName;
        option.textContent = category.catName;
        categorySelect.appendChild(option);
    });

    // Populate the select element with subcategory names
    subCategories.forEach(subCategory => {
        const option = document.createElement('option');
        option.value = subCategory.subCategory;
        option.textContent = subCategory.subCategory;
        subCategorySelect.appendChild(option);
    });

    // Populate the select element with brand names
    brands.forEach(brand => {
        const option = document.createElement('option');
        option.value = brand.brandname;
        option.textContent = brand.brandname;
        brandSelect.appendChild(option);
    });

    // Populate the product table
    const productTableBody = document.getElementById('productTableBody');
    productTableBody.innerHTML = '';

    products.forEach((product, index) => {
        const row = `
            <tr>
                <td>
                    <label class="checkboxs">
                        <input type="checkbox" id="select-${index}">
                        <span class="checkmarks"></span>
                    </label>
                </td>
                <td>${index + 1}</td>
                <td>${product.productName}</td>
                <td>${product.category}</td>
                <td>${product.subCategory}</td>
                <td>${product.brand}</td>
                <td>${product.unit}</td>
                <td>${product.sku}</td>
                <td>${product.minQty}</td>
                <td>${product.qty}</td>
                <td>${product.description}</td>
                <td>${product.tax}</td>
                <td>${product.discountType}</td>
                <td>${product.price}</td>
                <td>${product.status}</td>
                <td>
                    <a class="me-3" href="product-details.html">
                        <img src="assets/img/icons/eye.svg" alt="View">
                    </a>
                    <a class="me-3" href="javascript:void(0);" onclick="editProduct(0)">
                        <img src="assets/img/icons/edit.svg" alt="Edit">
                    </a>
                    <a class="confirm-text" href="javascript:void(0);" onclick="deleteProduct(0)">
                        <img src="assets/img/icons/delete.svg" alt="Delete">
                    </a>
                </td>
            </tr>
        `;
        productTableBody.innerHTML += row;
    });
});

function saveProductData() {
    // Get input values
    const productName = document.getElementById('productName').value;
    const category = document.getElementById('category').value;
    const subCategory = document.getElementById('subCategory').value;
    const brand = document.getElementById('brand').value;
    const unit = document.getElementById('unit').value;
    const sku = document.getElementById('sku').value;
    const minQty = document.getElementById('minQty').value;
    const qty = document.getElementById('qty').value;
    const description = document.getElementById('description').value;
    const tax = document.getElementById('tax').value;
    const discountType = document.getElementById('discountType').value;
    const price = document.getElementById('price').value;
    const status = document.getElementById('status').value;

    // Simple validation
    if (!productName || !category || !subCategory || !brand || !unit || !sku || !price || !qty) {
        alert('Please fill in all required fields: Product Name, Category, Subcategory, Brand, Unit, SKU, Price, and Quantity');
        return;
    }

    // Create product object
    const productData = {
        productName,
        category,
        subCategory,
        brand,
        unit,
        sku,
        minQty,
        qty,
        description,
        tax,
        discountType,
        price,
        status
    };
        

    // Check if 'products' already exists in local storage
    if (localStorage.getItem('products')) {
        // Retrieve existing products data from local storage
        const existingProducts = JSON.parse(localStorage.getItem('products'));

        // Add new product data to existing data
        existingProducts.push(productData);

        // Update 'products' in local storage
        localStorage.setItem('products', JSON.stringify(existingProducts));
    } else {
        // Create new 'products' array and add the product data
        const newProducts = [productData];

        // Set 'products' in local storage
        localStorage.setItem('products', JSON.stringify(newProducts));
    }

    // Redirect to productlist.html
    window.location.href = 'productlist.html';

    // Alert the user that the data has been saved
    alert('Product data has been saved successfully!');
}



