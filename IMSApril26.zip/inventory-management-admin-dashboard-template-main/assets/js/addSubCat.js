document.addEventListener('DOMContentLoaded', () => {
    // Retrieve the generated category code from session storage
    const generatedCategoryCode = sessionStorage.getItem('generatedCategoryCode');

    // Set the generated category code to the input field
    document.getElementById('categoryCode').value = generatedCategoryCode || '';
    // Retrieve data from local storage
    const categories = JSON.parse(localStorage.getItem('category')) || [];

    // Select the parent category dropdown
    const parentCategorySelect = document.getElementById('parentCategory');

    // Clear existing options
    parentCategorySelect.innerHTML = '<option>Choose Category</option>';

    // Populate the select element with catNames
    categories.forEach(category => {
        const option = document.createElement('option');
        option.value = category.catName;
        option.textContent = category.catName;
        parentCategorySelect.appendChild(option);
    });
});
function generateCategoryCode() {
    // Generate category code (self-incrementing with 'SUB' prefix)
    const existingSubCategories = JSON.parse(localStorage.getItem('subCategories')) || [];
    const categoryCode = 'SUB' + (existingSubCategories.length + 1).toString().padStart(3, '0');

    // Set the category code to the disabled input field on the subaddcategory.html page
    sessionStorage.setItem('generatedCategoryCode', categoryCode);
}

function saveSubData() {
    // Get input values
    const parentCategory = document.getElementById('parentCategory').value;
    const subCategory = document.getElementById('subCategory').value;
    const descript = document.getElementById('descript').value;

    // Validate input
    if (!parentCategory || !subCategory || !descript) {
        alert('Please fill out all required fields.');
        return;
    }

    // Generate category code (self-incrementing with 'SUB' prefix)
    const existingSubCategories = JSON.parse(localStorage.getItem('subCategories')) || [];
    const categoryCode = 'SUB' + (existingSubCategories.length + 1).toString().padStart(3, '0');

    // Set the category code to the disabled input field
    document.getElementById('categoryCode').value = categoryCode;

    // Create sub-category object
    const subCategoryData = {
        parentCategory,
        subCategory,
        categoryCode,
        descript
    };

    // Check if 'subCategories' already exists in local storage
    if (localStorage.getItem('subCategories')) {
        // Retrieve existing sub-categories data from local storage
        const existingSubCategories = JSON.parse(localStorage.getItem('subCategories'));

        // Add new sub-category data to existing data
        existingSubCategories.push(subCategoryData);

        // Update 'subCategories' in local storage
        localStorage.setItem('subCategories', JSON.stringify(existingSubCategories));
    } else {
        // Create new 'subCategories' array and add the sub-category data
        const newSubCategories = [subCategoryData];

        // Set 'subCategories' in local storage
        localStorage.setItem('subCategories', JSON.stringify(newSubCategories));
    }

    // Clear the input fields after saving
    document.getElementById('parentCategory').value = 'Choose Category';
    document.getElementById('subCategory').value = '';
    document.getElementById('descript').value = '';

    // Redirect to subcategorylist.html
    window.location.href = 'subcategorylist.html';
}


function updateSubCategory() {
    // Retrieve input values
    const parentCategory = document.getElementById('parentCategory').value;
    const subCategory = document.getElementById('subCategory').value;
    const categoryCode = document.getElementById('categoryCode').value;
    const descript = document.getElementById('descript').value;

    // Retrieve the index of the edited sub-category from the URL
    const urlParams = new URLSearchParams(window.location.search);
    const index = parseInt(urlParams.get('index'));

    // Retrieve existing sub-categories data from local storage
    const existingSubCategories = JSON.parse(localStorage.getItem('subCategories')) || [];

    // Update the sub-category data at the specified index
    existingSubCategories[index] = {
        parentCategory,
        subCategory,
        categoryCode,
        descript
    };

    // Update 'subCategories' in local storage
    localStorage.setItem('subCategories', JSON.stringify(existingSubCategories));

    // Redirect to subcategorylist.html
    window.location.href = 'subcategorylist.html';

    // Alert the user that the data has been updated
    alert('Sub-category data has been updated successfully!');
}

document.addEventListener('DOMContentLoaded', () => {
    // Retrieve sub-category data from local storage
    const subCategories = JSON.parse(localStorage.getItem('subCategories')) || [];

    // Select the table body
    const subCategoryTableBody = document.getElementById('subCategoryTableBody');

    // Clear existing rows
    subCategoryTableBody.innerHTML = '';

    // Populate the table with sub-category data
    subCategories.forEach((subCategory, index) => {
        const row = `
            <tr>
                <td>
                    <label class="checkboxs">
                        <input type="checkbox" id="select-${index}">
                        <span class="checkmarks"></span>
                    </label>
                </td>
                <td>${index + 1}</td>
                <td>${subCategory.parentCategory}</td>
                <td>${subCategory.subCategory}</td>
                <td>${subCategory.categoryCode}</td>
                <td>${subCategory.descript}</td>
                <td>Admin</td>
                <td>
                    <a class="me-3" href="javascript:void(0);" onclick="editSubCategory(${index})">
                        <img src="assets/img/icons/edit.svg" alt="Edit">
                    </a>
                    <a class="me-3 confirm-text" href="javascript:void(0);" onclick="deleteSubCategory(${index})">
                        <img src="assets/img/icons/delete.svg" alt="Delete">
                    </a>
                </td>
            </tr>
        `;
        subCategoryTableBody.innerHTML += row;
    });
});

function editSubCategory(index) {
    // Retrieve sub-category data from local storage
    const subCategories = JSON.parse(localStorage.getItem('subCategories')) || [];

    // Get the sub-category data to edit
    const subCategoryData = subCategories[index];

    // Store the edited sub-category data in session storage
    sessionStorage.setItem('editedSubCategory', JSON.stringify(subCategoryData));

    // Redirect to editsubcategory.html
    window.location.href = `editsubcategory.html?index=${index}`;
}

function deleteSubCategory(index) {
    // Retrieve sub-category data from local storage
    const subCategories = JSON.parse(localStorage.getItem('subCategories')) || [];

    // Remove the sub-category data
    subCategories.splice(index, 1);

    // Update 'subCategories' in local storage
    localStorage.setItem('subCategories', JSON.stringify(subCategories));

    // Reload the page to refresh the table
    window.location.reload();
}
