function saveData() {
    let catName = document.getElementById("catName").value;
    let catCode = document.getElementById("catCode").value;
    let catDescript = document.getElementById("catDescript").value;

    console.log(catName + catCode + catDescript);

    let categories = JSON.parse(localStorage.getItem("category")) || [];

    if (categories.some(v => v.catCode === catCode)) {
        alert("Category is already existing");
    } else {
        categories.push({
            "catName": catName,
            "catCode": catCode,
            "catDescript": catDescript
        });
        localStorage.setItem("category", JSON.stringify(categories));
        alert("Category added successfully");
        // Redirect to the category list page
        window.location.href = "categorylist.html";
    }
}

function populateTable() {
    let categories = JSON.parse(localStorage.getItem("category")) || [];
    let tableBody = document.getElementById("categoryTableBody");
    
    tableBody.innerHTML = ""; // Clear the table body
    
    categories.forEach((category, index) => {
        let row = `
            <tr>
                <td>
                    <label class="checkboxs">
                        <input type="checkbox" id="checkbox-${index}">
                        <span class="checkmarks"></span>
                    </label>
                </td>
                <td></td>
                <td>${category.catName}</td>
                <td>${category.catCode}</td>
                <td>${category.catDescript}</td>
                <td>Admin</td>
                <td>
                    <a class="me-3" href="javascript:void(0);" onclick="editCategory(${index})">
                        <img src="assets/img/icons/edit.svg" alt="Edit">
                    </a>
                    <a class="me-3 confirm-text" href="javascript:void(0);" onclick="deleteCategory(${index})">
                        <img src="assets/img/icons/delete.svg" alt="Delete">
                    </a>
                </td>
            </tr>
        `;
        tableBody.innerHTML += row;
    });
}

function deleteCategory(index) {
    let categories = JSON.parse(localStorage.getItem("category")) || [];
    
    // Remove the category from the array
    categories.splice(index, 1);
    
    // Update the local storage
    localStorage.setItem("category", JSON.stringify(categories));
    
    // Repopulate the table
    //populateTable();
    window.location.href = "categorylist.html";

}

function editCategory(index) {
    // Redirect to editcategory.html with the index as a query parameter
    window.location.href = `editcategory.html?index=${index}`;
}

document.addEventListener("DOMContentLoaded", function() {
    populateTable();
    
    // Get new category data from query parameters and add it to the local storage
    const urlParams = new URLSearchParams(window.location.search);
    const catName = urlParams.get('catName');
    const catCode = urlParams.get('catCode');
    const catDescript = urlParams.get('catDescript');

    if (catName && catCode && catDescript) {
        let categories = JSON.parse(localStorage.getItem("category")) || [];
        let newCategory = {
            "catName": catName,
            "catCode": catCode,
            "catDescript": catDescript
        };
        categories.push(newCategory);
        localStorage.setItem("category", JSON.stringify(categories));
    }
});

function updateCategory() {
    const urlParams = new URLSearchParams(window.location.search);
    const index = urlParams.get('index');
    
    if (index !== null) {
        let catName = document.getElementById("catName").value;
        let catCode = document.getElementById("catCode").value;
        let catDescript = document.getElementById("catDescript").value;

        let categories = JSON.parse(localStorage.getItem("category")) || [];

        if (categories.some((v, i) => i != index && v.catCode === catCode)) {
            alert("Category code is already existing");
        } else {
            categories[index] = {
                "catName": catName,
                "catCode": catCode,
                "catDescript": catDescript
            };
            localStorage.setItem("category", JSON.stringify(categories));
            alert("Category updated successfully");
            window.location.href = "categorylist.html";
        }
    }
}
