document.addEventListener('DOMContentLoaded', () => {
    // Retrieve data from local storage
    const categoryData = JSON.parse(localStorage.getItem('category'));

    // Select the parent category dropdown
    const parentCategorySelect = document.getElementById('parentCategory');

    // Clear existing options
    parentCategorySelect.innerHTML = '<option>Choose Category</option>';

    // Populate the select element with catNames
    if (categoryData && categoryData.catNames) {
        categoryData.catNames.forEach(catName => {
            const option = document.createElement('option');
            option.value = catName;
            option.textContent = catName;
            parentCategorySelect.appendChild(option);
        });
    }
});

function saveSubData() {
    // Your save function here
}
