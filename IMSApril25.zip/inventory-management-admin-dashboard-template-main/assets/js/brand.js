document.addEventListener('DOMContentLoaded', function() {
    const brandAddBtn = document.getElementById('brandAdd');

    brandAddBtn.addEventListener('click', function(event) {
        event.preventDefault();

        console.log('Submit button clicked');  // Debugging line

        const brandName = document.querySelector('#BrandADD .col-lg-3 input[type="text"]').value;
        const brandDescription = document.querySelector('#BrandADD .col-lg-12 textarea').value;
        const brandImage = document.querySelector('#BrandADD .col-lg-12 input[type="file"]').files[0];

        console.log(brandName, brandDescription, brandImage);  // Debugging line

        if (brandName && brandDescription) {
            addBrandToList(brandName, brandDescription, brandImage);
            // Reset form
            document.querySelector('#BrandADD .col-lg-3 input[type="text"]').value = '';
            document.querySelector('#BrandADD .col-lg-12 textarea').value = '';
            document.querySelector('#BrandADD .col-lg-12 input[type="file"]').value = '';

            // Show success message
            alert('Brand added successfully!');

            // Redirect to brandlist.html
            window.location.href = 'brandlist.html';
        } else {
            alert('Please fill in all fields.');
        }
    });

    function addBrandToList(name, description, image) {
        const tableBody = document.querySelector('.datanew tbody');

        const newRow = document.createElement('tr');
        newRow.innerHTML = `
            <td>
                <label class="checkboxs">
                    <input type="checkbox">
                    <span class="checkmarks"></span>
                </label>
            </td>
            <td>
                <a class="product-img">
                    <img src="${image ? URL.createObjectURL(image) : 'assets/img/icons/default-brand.png'}" alt="product">
                </a>
            </td>
            <td>${name}</td>
            <td>${description}</td>
            <td>
                <a class="me-3" href="editbrand.html">
                    <img src="assets/img/icons/edit.svg" alt="img">
                </a>
                <a class="me-3 confirm-text" href="javascript:void(0);">
                    <img src="assets/img/icons/delete.svg" alt="img">
                </a>
            </td>
        `;

        tableBody.appendChild(newRow);
    }
});
