document.addEventListener('DOMContentLoaded', () => {
    // Retrieve data from local storage
    const categories = JSON.parse(localStorage.getItem('category')) || [];
    const subCategories = JSON.parse(localStorage.getItem('subCategories')) || [];
    const brands = JSON.parse(localStorage.getItem('brand')) || [];

    // Select the category, subcategory, and brand dropdowns
    const categorySelect = document.getElementById('category');
    const subCategorySelect = document.getElementById('subCategory');
    const brandSelect = document.getElementById('brand');

    // Clear existing options
    categorySelect.innerHTML = '<option>Choose Category</option>';
    subCategorySelect.innerHTML = '<option>Choose Sub Category</option>';
    brandSelect.innerHTML = '<option>Choose Brand</option>';

    // Populate the select element with category names
    categories.forEach(category => {
        const option = document.createElement('option');
        option.value = category.catName;
        option.textContent = category.catName;
        categorySelect.appendChild(option);
    });

    // Populate the select element with subcategory names
    subCategories.forEach(subCategory => {
        const option = document.createElement('option');
        option.value = subCategory.subCategory;
        option.textContent = subCategory.subCategory;
        subCategorySelect.appendChild(option);
    });

    // Populate the select element with brand names
    brands.forEach(brand => {
        const option = document.createElement('option');
        option.value = brand.brandname;
        option.textContent = brand.brandname;
        brandSelect.appendChild(option);
    });

    // Populate the product table
    const products = JSON.parse(localStorage.getItem('products')) || [];
    const productTableBody = document.getElementById('productTableBody');
    productTableBody.innerHTML = '';

    products.forEach((product, index) => {
        const row = `
            <tr>
                <td>
                    <label class="checkboxs">
                        <input type="checkbox" id="select-${index}">
                        <span class="checkmarks"></span>
                    </label>
                </td>
                <td class="productimgname">
                    <a href="javascript:void(0);" class="product-img">
                        <img src="assets/img/product/product1.jpg" alt="product">
                    </a>
                    <a href="javascript:void(0);">${product.productName}</a>
                </td>
                <td>${product.sku}</td>
                <td>${product.category}</td>
                <td>${product.brand}</td>
                <td>${product.price}</td>
                <td>${product.unit}</td>
                <td>${product.qty}</td>
                <td>Admin</td>
                <td>
                    <a class="me-3" href="product-details.html">
                        <img src="assets/img/icons/eye.svg" alt="img">
                    </a>
                    <a class="me-3" href="editproduct.html" onclick="editProduct(${index})">
                        <img src="assets/img/icons/edit.svg" alt="img">
                    </a>
                    <a class="confirm-text" href="javascript:void(0);" onclick="deleteProduct(${index})">
                        <img src="assets/img/icons/delete.svg" alt="img">
                    </a>
                </td>
            </tr>
        `;
        productTableBody.innerHTML += row;
    });
});

function filterProducts() {
    const categoryFilter = document.getElementById('category').value;
    const subCategoryFilter = document.getElementById('subCategory').value;
    const brandFilter = document.getElementById('brand').value;

    const products = JSON.parse(localStorage.getItem('products')) || [];
    const filteredProducts = products.filter(product => {
        return (categoryFilter === 'Choose Category' || product.category === categoryFilter) &&
               (subCategoryFilter === 'Choose Sub Category' || product.subCategory === subCategoryFilter) &&
               (brandFilter === 'Choose Brand' || product.brand === brandFilter);
    });

    const productTableBody = document.getElementById('productTableBody');
    productTableBody.innerHTML = '';

    filteredProducts.forEach((product, index) => {
        const row = `
            <tr>
                <td>
                    <label class="checkboxs">
                        <input type="checkbox" id="select-${index}">
                        <span class="checkmarks"></span>
                    </label>
                </td>
                <td class="productimgname">
                    <a href="javascript:void(0);" class="product-img">
                        <img src="assets/img/product/product1.jpg" alt="product">
                    </a>
                    <a href="javascript:void(0);">${product.productName}</a>
                </td>
                <td>${product.sku}</td>
                <td>${product.category}</td>
                <td>${product.brand}</td>
                <td>${product.price}</td>
                <td>${product.unit}</td>
                <td>${product.qty}</td>
                <td>Admin</td>
                <td>
                    <a class="me-3" href="product-details.html">
                        <img src="assets/img/icons/eye.svg" alt="img">
                    </a>
                    <a class="me-3" href="editproduct.html" onclick="editProduct(${index})">
                        <img src="assets/img/icons/edit.svg" alt="img">
                    </a>
                    <a class="confirm-text" href="javascript:void(0);" onclick="deleteProduct(${index})">
                        <img src="assets/img/icons/delete.svg" alt="img">
                    </a>
                </td>
            </tr>
        `;
        productTableBody.innerHTML += row;
    });
}

function editProduct(index) {
    const products = JSON.parse(localStorage.getItem('products')) || [];
    const productData = products[index];
    sessionStorage.setItem('editedProduct', JSON.stringify(productData));
    window.location.href = `editproduct.html?index=${index}`;
}

function deleteProduct(index) {
    const products = JSON.parse(localStorage.getItem('products')) || [];
    products.splice(index, 1);
    localStorage.setItem('products', JSON.stringify(products));
    window.location.reload();
}