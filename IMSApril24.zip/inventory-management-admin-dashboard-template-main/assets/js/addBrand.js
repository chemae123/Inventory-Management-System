// function saveData() {
//     let brandname = document.getElementById("brandname").value;
//     let descript = document.getElementById("descript").value;

//     let brands = JSON.parse(localStorage.getItem("brand")) || [];

//     if (brands.some((v) => v.brandname === brandname)) {
//         alert("Brand is already existing");
//     } else {
//         brands.push({
//             brandname: brandname,
//             descript: descript
//         });
//         localStorage.setItem("brand", JSON.stringify(brands));

//         // Update brandlist.html
//         updateBrandList();

//         // Notify user and redirect
//         alert("Brand added successfully!");
//         window.location.href = 'brandlist.html';
//     }
// }

// function editBrand(index) {
//     let brands = JSON.parse(localStorage.getItem("brand")) || [];
//     const brand = brands[index];

//     // Populate the edit form with the selected brand data
//     document.getElementById('edit-brandname').value = brand.brandname;
//     document.getElementById('edit-descript').value = brand.descript;

//     // Redirect to editbrand.html
//     window.location.href = `editbrand.html?id=${index}`;
// }
// function deleteBrand(index) {
//     let brands = JSON.parse(localStorage.getItem("brand")) || [];

//     // Remove the brand from the array
//     brands.splice(index, 1);

//     // Update the localStorage
//     localStorage.setItem("brand", JSON.stringify(brands));

//     // Update the brandlist.html
//     updateBrandList();

//     // Redirect to brandlist.html
//     window.location.href = 'brandlist.html';
// }

// function updateBrandList() {
//     const brandTableBody = document.getElementById('brandTableBody');
  
//     if (brandTableBody) {
//       brandTableBody.innerHTML = ''; // Clear the table body
  
//       const brands = JSON.parse(localStorage.getItem("brand")) || [];
  
//       if (brands.length === 0) {
//         brandTableBody.innerHTML = `
//           <tr>
//             <td colspan="5" class="text-center">No brands available</td>
//           </tr>
//         `;
//       } else {
//         brands.forEach((brand, index) => {
//           const row = `
//             <tr>
//               <td>
//                 <label class="checkboxs">
//                   <input type="checkbox" class="brand-checkbox" data-id="${index}">
//                   <span class="checkmarks"></span>
//                 </label>
//               </td>
//               <td></td>
//               <td>${brand.brandname}</td>
//               <td>${brand.descript}</td>
//               <td>
//                 <a class="me-3" href="editbrand.html?id=${index}" onclick="editBrand(${index})">
//                   <img src="assets/img/icons/edit.svg" alt="Edit">
//                 </a>
//                 <a class="me-3 confirm-text" href="javascript:void(0);" onclick="deleteBrand(${index})">
//                   <img src="assets/img/icons/delete.svg" alt="Delete">
//                 </a>
//               </td>
//             </tr>
//           `;
//           brandTableBody.innerHTML += row;
//         });
//       }
//     } else {
//       console.error("brandTableBody is null");
//     }
//   }
//   const urlParams = new URLSearchParams(window.location.search);
//   const brandId = urlParams.get('id');
  
//   document.addEventListener("DOMContentLoaded", function() {
//     if (brandId !== null) {
//       loadBrandData();
//     } else {
//       updateBrandList();
//     }
//   });


//   function loadBrandData() {
//     let brands = JSON.parse(localStorage.getItem("brand")) || [];
  
//     if (brands.length > brandId && brands[brandId]) {
//       document.getElementById('edit-brandname').value = brands[brandId].brandname;
//       document.getElementById('edit-descript').value = brands[brandId].descript;
//     } else {
//       alert('Brand not found');
//       window.location.href = 'brandlist.html';
//     }
//   }
  
//   function saveEditData() {
//     const brandname = document.getElementById('edit-brandname').value;
//     const descript = document.getElementById('edit-descript').value;
  
//     let brands = JSON.parse(localStorage.getItem("brand")) || [];
  
//     if (brands.length > brandId && brands[brandId]) {
//       brands[brandId] = {
//         "brandname": brandname,
//         "descript": descript
//       };
  
//       localStorage.setItem("brand", JSON.stringify(brands));
      
//       alert('Brand updated successfully');
//       window.location.href = `brandlist.html`;
//     } else {
//       alert('Brand not found');
//     }
//   }